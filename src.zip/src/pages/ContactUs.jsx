import React from "react";
import { Helmet } from "react-helmet";

export default function ContactUs() {
  return (
    <div>
      <Helmet>
        <title>Contact Us</title>
      </Helmet>
      ContactUs
    </div>
  );
}
