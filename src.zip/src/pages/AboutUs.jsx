import React from "react";
import { Helmet } from "react-helmet";

export default function AboutUs() {
  return (
    <div>
      <Helmet>
        <title>About Us</title>
      </Helmet>
      AboutUs
    </div>
  );
}
