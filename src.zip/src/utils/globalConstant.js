globalThis.SERVER_URL = "http://localhost:3000";
